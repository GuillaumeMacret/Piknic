<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="enemies" tilewidth="48" tileheight="48" tilecount="64" columns="8">
 <image source="s1enemies.gif" width="410" height="400"/>
</tileset>
