<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="sonicTileset" tilewidth="48" tileheight="48" tilecount="1600" columns="40">
 <image source="sonicTilemap.png" width="1920" height="1920"/>
</tileset>
